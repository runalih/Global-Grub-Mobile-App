# Data Schema
## Position
```java
class Position{
    public Double lat;
    public Double lon;
    public Position(Double lat, Double lon){
        this.lat = lat;
        this.lon = lon;
    }
}
```

## Food
```java
class Food{
    public String name;
    public Integer rating;
    public ArrayList<String> photos;
    public String country;
    public Position position;
    public Date date;
    public Recommend(String name, ArrayList<String> photos, String country, String history, ArrayList<String> ingredients, ArrayList<Position> locationToBuy){
        this.name = name;
        this.photos = photos;
        this.country = country;
        this.history = history;
        this.ingredients = ingredients;
        this.locationToBuy = locationToBuy;
    }
}
```

## Recommend
```java
class Recommend{
    public String name;
    public ArrayList<String> photos;
    public String country;
    public String history;
    public ArrayList<String> ingredients;
    public ArrayList<Position> locationToBuy;
    public Recommend(String name, ArrayList<String> photos, String country, String history, ArrayList<String> ingredients, ArrayList<Position> locationToBuy){
        this.name = name;
        this.photos = photos;
        this.country = country;
        this.history = history;
        this.ingredients = ingredients;
        this.locationToBuy = locationToBuy;
    }
}
```

## Trip
```java
class Trip{
    public Date date;
    public String country;
    public ArrayList<Integer> foodIDs;
    public Trip(Date date, String country, ArrayList<Integer> foodIDs){
        this.date = date;
        this.country = country;
        this.foodIDs = foodIDs;
    }
}
```

## Country
```java
public class Country{
    private String name;
    private Position position;
    public Country(){
        this.name = "Test Country";
        this.position = new Position();
    }
    public Country(String name, Position position){
        this.name = name;
        this.position = position;
    }
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Position getPosition(){
        return this.position;
    }
    public void setPosition(Position position){
        this.position = position;
    }
}
```

# GlobalGrub Class Documentation
**Use MainActivity.globalgrub to operate the data.**
## Description
`GlobalGrub` is a class that manages various aspects of a global food and travel application, including operations related to food, recommendations, countries, and trips.
**Use MainActivity.globalgrub to operate the data.**
## Methods
**Use MainActivity.globalgrub to operate the data.**

### Food Management Methods

#### `public Boolean addFood(Food food)`
Adds a new food item to the food manager.
- **Arguments**:
  - `food`: (`Food`) The food item to be added.
- **Returns**:
  - (`Boolean`) `true` if the food is successfully added, `false` otherwise.

#### `public void deleteFood(int index)`
Deletes a food item from the food manager by index.
- **Arguments**:
  - `index`: (`int`) The index of the food item to be deleted.

#### `public void editFood(int index, Food food)`
Edits a food item at the specified index.
- **Arguments**:
  - `index`: (`int`) The index of the food item to edit.
  - `food`: (`Food`) The new food item to replace the old one.

#### `public Food getFood(int index)`
Retrieves a food item by index.
- **Arguments**:
  - `index`: (`int`) The index of the food item to retrieve.
- **Returns**:
  - (`Food`) The requested food item.

#### `public Hashtable<Integer, Food> getAllFoods()`
Gets all food items with their indices.
- **Returns**:
  - (`Hashtable<Integer, Food>`) A hashtable mapping indices to food items.

#### `public List<Food> getFoodList()`
Gets a list of all food items.
- **Returns**:
  - (`List<Food>`) A list of all food items.

### Recommendation Management Methods

#### `public boolean addRecommendation(String country, Recommendation foodIntro)`
Adds a new recommendation for a specific country.
- **Arguments**:
  - `country`: (`String`) The country name.
  - `foodIntro`: (`Recommendation`) The recommendation to be added.
- **Returns**:
  - (`boolean`) `true` if the recommendation is successfully added, `false` otherwise.

#### `public boolean deleteRecommendation(String country, Recommendation foodIntro)`
Deletes a recommendation for a specific country.
- **Arguments**:
  - `country`: (`String`) The country name.
  - `foodIntro`: (`Recommendation`) The recommendation to be deleted.
- **Returns**:
  - (`boolean`) `true` if the recommendation is successfully deleted, `false` otherwise.

#### `public Hashtable<String, List<Recommendation>> getRecommendation(String country)`
Gets all recommendations for a specific country.
- **Arguments**:
  - `country`: (`String`) The country name.
- **Returns**:
  - (`Hashtable<String, List<Recommendation>>`) A hashtable mapping countries to lists of recommendations.

#### `public List<Recommendation> getRecommendationList(String country)`
Gets a list of recommendations for a specific country.
- **Arguments**:
  - `country`: (`String`) The country name.
- **Returns**:
  - (`List<Recommendation>`) A list of recommendations for the specified country.

### Country Management Methods

#### `public void addCountry(Country country)`
Adds a new country.
- **Arguments**:
  - `country`: (`Country`) The country to be added.

#### `public void removeCountry(String country)`
Removes a country.
- **Arguments**:
  - `country`: (`String`) The name of the country to be removed.

#### `public boolean containsCountry(String country)`
Checks if a country exists.
- **Arguments**:
  - `country`: (`String`) The name of the country to check.
- **Returns**:
  - (`boolean`) `true` if the country exists, `false` otherwise.

#### `public Hashtable<String,Country> getCountries()`
Gets all countries.
- **Returns**:
  - (`Hashtable<String,Country>`) A hashtable of all countries.

#### `public List<Country> getCountryList()`
Gets a list of all countries.
- **Returns**:
    - (`List<Country>`) A list of all countries.

### Trip Management Methods

#### `public boolean addTrip(Trip trip)`
Adds a new trip, ensuring all food IDs in the trip exist.
- **Arguments**:
  - `trip`: (`Trip`) The trip to be added.
- **Returns**:
  - (`boolean`) `true` if the trip is successfully added, `false` otherwise.

#### `public boolean deleteTrip(Integer id)`
Deletes a trip by its ID.
- **Arguments**:
  - `id`: (`Integer`) The ID of the trip to be deleted.
- **Returns**:
  - (`boolean`) `true` if the trip is successfully deleted, `false` otherwise.

#### `public boolean editTrip(Integer id, Trip trip)`
Edits a trip by its ID, ensuring all new food IDs in the trip exist.
- **Arguments**:
  - `id`: (`Integer`) The ID of the trip to be edited.
  - `trip`: (`Trip`) The new trip data.
- **Returns**:
  - (`boolean`) `true` if the trip is successfully edited, `false` otherwise.

#### `public Trip getTrip(Integer id)`
Retrieves a trip by its ID.
- **Arguments**:
  - `id`: (`Integer`) The ID of the trip to retrieve.
- **Returns**:
  - (`Trip`) The requested trip.

#### `public Hashtable<Integer, Trip> getTrips()`
Gets all trips with their IDs.
- **Returns**:
  - (`Hashtable<Integer, Trip>`) A hashtable mapping trip IDs to trips.

#### `public List<Trip> getTripList()`
Gets a list of all trips.
- **Returns**:
  - (`List<Trip>`) A list of all trips.

## General Information
This class is a part of the `com.example.globalgrub.manager` package and utilizes various model classes (`Country`, `Food`, `Recommendation`, `Trip`) and utility classes (`CSVLoader`) for its operations.
