# globalgrub
An application for users to track and explore foods they eat on their travels.

# installation
Download Android Studio and run using the play button

# How to get data
**See DataInterface.java file and DataREADME.md** 