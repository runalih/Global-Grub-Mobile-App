package com.example.globalgrub;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.ViewFlipper;

import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.adapters.DishAdapter2;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Trip;

import java.util.List;

public class DishActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dish_page);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        // 为每个按钮设置相同的点击事件处理器
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button3.setImageResource(R.drawable.fast_food_clicked);
        TextView food_text = findViewById(R.id.food_text);
        food_text.setTextColor(Color.parseColor("#BCA538"));

//        final String[][] foodName = {{
//                "Tacos Al Pastor", "Döner Kebab",
//                "Cuban Sandwich", "Butter Chicken",
//                "Chicken Adobo"
//        }};
//
//        final String[][] country = {{
//                "Mexico", "Germany",
//                "Cuba", "India",
//                "Philliphines"
//        }};
//
//
//        final String[][] place = {{"ABC Restaurant", "ABC Restaurant", "ABC Restaurant", "ABC Restaurant", "ABC Restaurant"}};
//        final String[][] date = {{"2/1/2020", "2/1/2020", "2/1/2020", "2/1/2020", "2/1/2020"}};
//        final int[][] rating = {{5, 4, 5, 3, 2}};
//        final String[][] image1 = {{"chickenadobo1.png", "chickenadobo1.png", "chickenadobo1.png", "chickenadobo1.png", "chickenadobo1.png"}};
//        final String[][] image2 = {{"chickenadobo2.png", "chickenadobo2.png", "chickenadobo2.png", "chickenadobo2.png", "chickenadobo2.png"}};
        final int[] current_food_idx = {0};

        ViewFlipper vf = (ViewFlipper) findViewById( R.id.foodLogFlipper );
        ImageView foodDetailGoBack = findViewById(R.id.detailGoBack);
        ImageView foodEditGoBack = findViewById(R.id.editGoBack);
        ImageView deleteFood = findViewById(R.id.deleteFood);
        LinearLayout foodDetail = findViewById(R.id.foodDetailEdit);
        LinearLayout foodEditSave = findViewById(R.id.foodEditSave);

        TextView foodDetailName = findViewById(R.id.foodDetailName);
        RatingBar foodDetailRating = findViewById(R.id.foodDetailRating);
        TextView foodDetailCountry = findViewById(R.id.foodDetailCountry);
        TextView foodDetailPlace = findViewById(R.id.foodDetailPlace);
        ImageView foodDetailImage1 = findViewById(R.id.foodDetailImage1);
        ImageView foodDetailImage2 = findViewById(R.id.foodDetailImage2);

        EditText foodEditName = findViewById(R.id.foodEditName);
//        EditText foodEditRating = findViewById(R.id.foodEditRating);
        RatingBar foodEditRating = findViewById(R.id.foodEditRating);
        EditText foodEditCountry = findViewById(R.id.foodEditCountry);
        EditText foodEditPlace = findViewById(R.id.foodEditPlace);

//        MyListAdapter adapter = new MyListAdapter(this, foodName[0], country[0], date[0]);
        DishAdapter2 adapter = new DishAdapter2(this, MainActivity.globalgrub.getFoodList());
        Activity curr_activity = this;
        ListView foodList = findViewById(R.id.foodList);
        foodList.setAdapter(adapter);

        Drawable drawable = foodDetailRating.getProgressDrawable();
        drawable.setColorFilter(Color.parseColor("#FFDF00"), PorterDuff.Mode.SRC_ATOP);

        foodDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Food food = MainActivity.globalgrub.getFood(current_food_idx[0]);
                foodEditName.setText(food.getName());
                foodEditRating.setRating(food.getRating().floatValue());
                foodEditCountry.setText(food.getCountry());
                foodEditPlace.setText(food.getCountry());
                vf.showNext();
            }
        });
        deleteFood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int index = current_food_idx[0];
//                String[] newFoodName = new String[foodName[0].length - 1];
//                int[] newRating = new int[rating[0].length - 1];
//                String[] newDate = new String[date[0].length - 1];
//                String[] newCountry = new String[country[0].length - 1];
//                String[] newPlace = new String[place[0].length - 1];
//                String[] newImage1 = new String[image1[0].length - 1];
//                String[] newImage2 = new String[image2[0].length - 1];
//
//                for (int i = 0, j=0; i < foodName[0].length; i++) {
//                    if (i == current_food_idx[0]) {
//                        continue;
//                    }
//                    newFoodName[j] = foodName[0][i];
//                    newRating[j] = rating[0][i];
//                    newDate[j] = date[0][i];
//                    newCountry[j] = country[0][i];
//                    newPlace[j] = place[0][i];
//                    newImage1[j] = image1[0][i];
//                    newImage2[j] = image2[0][i];
//                    j++;
//                }
//                foodName[0] = newFoodName;
//                rating[0] = newRating;
//                date[0] = newDate;
//                country[0] = newCountry;
//                place[0] = newPlace;
//                image1[0] = newImage1;
//                image2[0] = newImage2;
                MainActivity.globalgrub.deleteFood(index);
                foodList.setAdapter(new DishAdapter2(curr_activity, MainActivity.globalgrub.getFoodList()));
                vf.showPrevious();
                vf.showPrevious();
            }
        });
        foodEditSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // save data
                int idx = current_food_idx[0];
                int valid = 1;
                // If foodEditName is empty, set error
                if(foodEditName.getText().toString().isEmpty()){
                    foodEditName.setError("Must Have Value");
                    valid = 0;
                }
                // If foodEditPlace is empty, set error
                if(foodEditPlace.getText().toString().isEmpty()){
                    foodEditPlace.setError("Must Have Value");
                    valid = 0;
                }
                // If foodEditRating is empty, set error
//                if(foodEditRating.getText().toString().isEmpty()){
//                    foodEditRating.setError("Must Have Value");
//                    valid = 0;
//                }
                // If foodEditRating is not valid value, set error
//                if(Double.valueOf(foodEditRating.getText().toString()) < 0 || Double.valueOf(foodEditRating.getText().toString()) > 5){
//                    foodEditRating.setError("Rating should between 0 - 5");
//                    valid = 0;
//                }
                if(valid == 0) return;
                MainActivity.globalgrub.getFood(idx).setName(foodEditName.getText().toString());
                MainActivity.globalgrub.getFood(idx).setCountry(foodEditPlace.getText().toString());
//                MainActivity.globalgrub.getFood(idx).setRating(Double.valueOf(foodEditRating.getText().toString()));
                MainActivity.globalgrub.getFood(idx).setRating((double) foodEditRating.getRating());
                foodList.setAdapter(new DishAdapter2(curr_activity, MainActivity.globalgrub.getFoodList()));
                vf.showPrevious();
                vf.showPrevious();
            }
        });
        foodDetailGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vf.showPrevious();
            }
        });

        foodEditGoBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                vf.showPrevious();
            }
        });
        foodList.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                List<Food> foods = MainActivity.globalgrub.getFoodList();
                Food currentFood = MainActivity.globalgrub.getFood(foods.get(position).getId());
                current_food_idx[0] = foods.get(position).getId();
                foodDetailName.setText(currentFood.getName());
                foodDetailRating.setRating(currentFood.getRating().floatValue());
                List<Trip> trips = MainActivity.globalgrub.getTripList();
                foodDetailCountry.setText("");
                for(Trip t : trips){
                    for(int fid : t.getFoodIDs()){
                        if(fid == currentFood.getId()){
                            foodDetailCountry.setText(t.getCountry());
                        }
                    }
                }
                foodDetailPlace.setText(currentFood.getCountry());
//                foodDetailName.setText(foodName[0][current_food_idx[0]]);
//                foodDetailRating.setNumStars(rating[0][current_food_idx[0]]);
//                foodDetailCountry.setText(country[0][current_food_idx[0]]);
//                foodDetailPlace.setText(place[0][current_food_idx[0]]);
//                int resID1 = getResources().getIdentifier(image1[0][current_food_idx[0]] , "id", getPackageName());
//                int resID2 = getResources().getIdentifier(image2[0][current_food_idx[0]] , "id", getPackageName());
//                foodDetailImage1.setBackgroundResource(resID1);
//                foodDetailImage2.setBackgroundResource(resID2);
                if(currentFood.getPhotos().size() == 0){

                }else if(currentFood.getPhotos().size() == 1){
                    foodDetailImage1.setImageURI(Uri.parse(currentFood.getPhotos().get(0)));
                }else{
                    foodDetailImage1.setImageURI(Uri.parse(currentFood.getPhotos().get(0)));
                    foodDetailImage2.setImageURI(Uri.parse(currentFood.getPhotos().get(1)));
                }

                vf.showNext();
//                if (position == 0) {
//                    //code specific to first list item
//                    vf.showNext();
//                } else if (position == 1) {
//                    //code specific to 2nd list item
//                    vf.showNext();
//                } else if (position == 2) {
//                    vf.showNext();
//                } else if (position == 3) {
//                    vf.showNext();
//                } else if (position == 4) {
//                    vf.showNext();
//                }
            }
        });

        int foodID = (int) getIntent().getIntExtra("foodID", -1);
        getIntent().removeExtra("foodID");
        if(foodID != -1){
            System.out.println(foodID);
            List<Food> foods = MainActivity.globalgrub.getFoodList();
            Food currentFood = MainActivity.globalgrub.getFood(foodID);
            current_food_idx[0] = foodID;
            foodDetailName.setText(currentFood.getName());
            foodDetailRating.setRating(currentFood.getRating().floatValue());
            List<Trip> trips = MainActivity.globalgrub.getTripList();
            foodDetailCountry.setText("");
            for(Trip t : trips){
                for(int fid : t.getFoodIDs()){
                    if(fid == currentFood.getId()){
                        foodDetailCountry.setText(t.getCountry());
                    }
                }
            }
            foodDetailPlace.setText(currentFood.getCountry());
            if(currentFood.getPhotos().size() == 0){

            }else if(currentFood.getPhotos().size() == 1){
                foodDetailImage1.setImageURI(Uri.parse(currentFood.getPhotos().get(0)));
            }else{
                foodDetailImage1.setImageURI(Uri.parse(currentFood.getPhotos().get(0)));
                foodDetailImage2.setImageURI(Uri.parse(currentFood.getPhotos().get(1)));
            }
            vf.showNext();
        }
    }
}