package com.example.globalgrub.manager;
import com.example.globalgrub.model.Recommendation;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class RecommendationManager {
    private Hashtable<String, List<Recommendation>> recommendations;

    public RecommendationManager() {
        recommendations = new Hashtable<>();
    }

    public boolean addRecommendation(String country, Recommendation recommend) {
        recommendations.computeIfAbsent(country, k -> new ArrayList<>()).add(recommend);
        return true;
    }

    public boolean deleteRecommendation(String country, Recommendation recommend) {
        List<Recommendation> countryRecommendations = recommendations.get(country);
        if (countryRecommendations == null) {
            return false;
        }
        return countryRecommendations.remove(recommend);
    }

    public Hashtable<String, List<Recommendation>> getRecommendation() {
        return recommendations;
    }

    public List<Recommendation> getRecommendationList(String country) {
        return recommendations.get(country);
    }
}