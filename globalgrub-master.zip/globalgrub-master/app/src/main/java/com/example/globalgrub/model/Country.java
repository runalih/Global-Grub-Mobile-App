package com.example.globalgrub.model;

import java.util.ArrayList;
import java.util.Date;

public class Country{
    private String name;
    private Position position;
    public Country(){
        this.name = "Test Country";
        this.position = new Position();
    }
    public Country(String name, Position position){
        this.name = name;
        this.position = position;
    }
    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name = name;
    }
    public Position getPosition(){
        return this.position;
    }
    public void setPosition(Position position){
        this.position = position;
    }
}