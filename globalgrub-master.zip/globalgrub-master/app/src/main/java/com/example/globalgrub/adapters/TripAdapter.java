package com.example.globalgrub.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.globalgrub.MainActivity;
import com.example.globalgrub.R;
import com.example.globalgrub.TripDetailActivity;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Trip;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TripAdapter extends ArrayAdapter<Trip> {
    private final Context context;
    private final List<Trip> trips;

    public TripAdapter(Context context, List<Trip> trips) {
        super(context, R.layout.list_item_trip, trips);
        this.context = context;
        this.trips = trips;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_trip, parent, false);
        }

        Trip currentTrip = getItem(position);

        if (currentTrip != null) {
            TextView text1 = convertView.findViewById(R.id.text1);
            TextView text2 = convertView.findViewById(R.id.text2);
            TextView text3 = convertView.findViewById(R.id.text3);
            ImageView im1 = convertView.findViewById(R.id.trip_img_1);

            text1.setText(currentTrip.getCountry());
            String startDateStr = processDateString(currentTrip.getStartDate().toString());
            String endDateStr = processDateString(currentTrip.getEndDate().toString());
            System.out.println(currentTrip.getStartDate());
            System.out.println(currentTrip.getEndDate());
            text2.setText(startDateStr);
            text3.setText(endDateStr);
            if (currentTrip.getFoodIDs().size() != 0) {
                Food tmp_food = MainActivity.globalgrub.getFood(currentTrip.getFoodIDs().get(0));
                if (tmp_food.getPhotos().size() != 0)
                    im1.setImageURI(Uri.parse(MainActivity.globalgrub.getFood(currentTrip.getFoodIDs().get(0)).getPhotos().get(0)));
            }
            else
                im1.setImageResource(R.drawable.food_icon);

            // country
            text1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    showPopup(currentTrip, v); // Show popup on nameTextView click
                    Intent intent = new Intent(context, TripDetailActivity.class);
                    intent.putExtra("trip", currentTrip);
                    context.startActivity(intent);

                }
            });

            text2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, TripDetailActivity.class);
                    intent.putExtra("trip", currentTrip);
                    context.startActivity(intent);
                }
            });
        }

        return convertView;
    }

    private void showPopup(Trip trip, View anchorView) {
        View popupView = LayoutInflater.from(context).inflate(R.layout.popup_trip, null);

        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;

        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView popupText1TextView = popupView.findViewById(R.id.popup_trip_text1);
        TextView popupText2TextView = popupView.findViewById(R.id.popup_trip_text2);
        TextView popupText3TextView = popupView.findViewById(R.id.popup_trip_text3);
        ListView popupList1View = popupView.findViewById(R.id.popup_trip_list1);

        popupText1TextView.setText(trip.getCountry());
        popupText2TextView.setText(processDateString(trip.getStartDate().toString()));
        popupText3TextView.setText(processDateString(trip.getEndDate().toString()));
        List<Integer> foodIDs = trip.getFoodIDs();
        List<Food> foods = new ArrayList<>();
        for (Integer foodID : foodIDs) {
            foods.add(MainActivity.globalgrub.getFood(foodID));
        }

        TripFoodAdapter tfAdapter = new TripFoodAdapter(context, foods);
        popupList1View.setAdapter(tfAdapter);

        ImageButton btnClosePopup = popupView.findViewById(R.id.btnTripClosePopup);
        btnClosePopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss(); // Dismiss the popup window on close button click
            }
        });

        popupWindow.showAtLocation(anchorView, Gravity.CENTER, 0, 0);
    }

    private static String processDateString(String input) {
//        input = input.replace("CST ", "");
        SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy");

        try {
            Date date = inputFormat.parse(input);
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid Date";
        }
    }
}

