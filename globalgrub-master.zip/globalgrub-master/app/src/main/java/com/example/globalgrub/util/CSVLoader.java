package com.example.globalgrub.util;

import android.content.Context;

import com.example.globalgrub.manager.CountryManager;
import com.example.globalgrub.manager.FoodManager;
import com.example.globalgrub.manager.RecommendationManager;
import com.example.globalgrub.model.*;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.opencsv.CSVReader;

import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.sql.Date;
import java.util.ArrayList;

public class CSVLoader {
    public static void loadCSVToRecommendationManager(Context context, String fileName, RecommendationManager manager) {
        System.out.println("fileName: " + fileName);
        try {
            InputStreamReader isReader = new InputStreamReader(context.getAssets().open(fileName));
            CSVReader csvReader = new CSVReader(isReader);
            String[] line;
            line = csvReader.readNext();
            while ((line = csvReader.readNext()) != null) {
                String name = line[0];
                Type listType = new TypeToken<ArrayList<String>>(){}.getType();
                ArrayList<String> photos = new Gson().fromJson(line[1], listType);
                String country = line[2];
                String history = line[3];
                ArrayList<String> ingredients = new Gson().fromJson(line[4], listType);
                ArrayList<Position> locationToBuy = new Gson().fromJson(line[5], new TypeToken<ArrayList<Position>>(){}.getType());
                Recommendation recommend = new Recommendation(name, photos, country, history, ingredients, locationToBuy);
                manager.addRecommendation(country, recommend);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void loadCSVToCountryManager(Context context, String fileName, CountryManager manager) {
        System.out.println("fileName: " + fileName);
        try {
            InputStreamReader isReader = new InputStreamReader(context.getAssets().open(fileName));
            CSVReader csvReader = new CSVReader(isReader);

            String[] line;
            while ((line = csvReader.readNext()) != null) {
                String name = line[0];
                manager.addCountry(new Country(name, new Position(Double.valueOf(line[1]),Double.valueOf(line[2]))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void loadCSVToFoodManager(Context context, String fileName, FoodManager manager){
        System.out.println("fileName: " + fileName);
        try {
//            System.out.println("fileName: " + fileName);
            InputStreamReader isReader = new InputStreamReader(context.getAssets().open(fileName));
            CSVReader csvReader = new CSVReader(isReader);
            String[] line;
            line = csvReader.readNext();
//
            while ((line = csvReader.readNext()) != null) {
                System.out.println("fileName: " + fileName);
                String name = line[0];
                Type listType = new TypeToken<ArrayList<String>>(){}.getType();
                ArrayList<String> photos = new Gson().fromJson(line[3], listType);
                String location = line[1];
                Date date = Date.valueOf(line[2]);
                Double rate = Double.valueOf(line[4]);
//                ArrayList<Position> locationToBuy = new Gson().fromJson(line[5], new TypeToken<ArrayList<Position>>(){}.getType());
                System.out.println(name+ " " + location);
                manager.addFood(new Food(name, rate, photos, location, new Position(), date, 0));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}