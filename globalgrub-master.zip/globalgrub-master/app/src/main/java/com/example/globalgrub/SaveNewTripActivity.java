package com.example.globalgrub;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.adapters.FoodOnTripAdapter;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Position;
import com.example.globalgrub.model.Trip;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SaveNewTripActivity extends AppCompatActivity {
    // TODO: deal with the foods added list
    // TODO: cleanup layout
    private List<String> allCountries;
    private EditText editTextSearch;
    private ListView listViewCountries;
    private List<String> filteredCountries;
    private EditText startDateEditText;
    private EditText endDateEditText;

    private View searchBar;
    private EditText countryFromSearchBar;
    private ArrayList<Integer> foodIdList;

    ArrayAdapter<String> adapter;
    private FoodOnTripAdapter foodAdapter;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            String foodName = data.getStringExtra("FOOD_NAME");
            String whereBought = data.getStringExtra("WHERE_BOUGHT");
            Double foodRating = data.getDoubleExtra("FOOD_RATING", 0.0);
        }
    }

    private void showCustomPopUp(View parentView, String message) {
        // Inflate the layout for the pop-up
        LayoutInflater inflater = LayoutInflater.from(SaveNewTripActivity.this);
        View customView = inflater.inflate(R.layout.custom_popup_layout, null);

        // Set the message
        TextView textView = customView.findViewById(R.id.popup_message);
        textView.setText(message);

        // Create a PopupWindow
        PopupWindow popupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        popupWindow.showAtLocation(parentView, Gravity.CENTER, 0, 0);

        // Close the pop-up after a delay (here, 4000 milliseconds)
        new Handler().postDelayed(popupWindow::dismiss, 20000);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        allCountries = new ArrayList<>(MainActivity.globalgrub.getCountries().keySet());
        foodIdList = new ArrayList<>();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_trip_page_continued);

        Intent intent = getIntent();
        String startDate = intent.getStringExtra("START_DATE");
        String endDate = intent.getStringExtra("END_DATE");
        String countryText = intent.getStringExtra("COUNTRY_TEXT");

        TextView whereTripTextIns = findViewById(R.id.whereTripTextIns);
        whereTripTextIns.setText(countryText);
        TextView whenTripEnds = findViewById(R.id.whenTripEndsTextIns);
        whenTripEnds.setText(endDate);
        TextView whenTripStarts = findViewById(R.id.whenTripStartsTextIns);
        whenTripStarts.setText(startDate);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        // set 4 onclick event handlers for the bottom
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);

        button1.setImageResource(R.drawable.globe_clicked);
        TextView home_text = findViewById(R.id.home_text);
        home_text.setTextColor(Color.parseColor("#BCA538"));

        // create the adapter for the list of foods
        List<Food> foodList = MainActivity.globalgrub.getTempFoodList();
        if (foodList != null && !foodList.isEmpty()) {
            List<String[]> items = new ArrayList<>();

            // Convert Food items to a format compatible with your adapter
            for (Food food : foodList) {
                String nameOfFood = food.getName();
                String whereBought = food.getCountry(); // Get 'whereBought' from Food object
                String foodRating = String.valueOf(food.getRating()); // Convert double to string
                String foodPhoto = String.valueOf(food.getPhotos().get(0));
                items.add(new String[]{nameOfFood, whereBought, foodRating, foodPhoto});
            }

            // Set the adapter with the retrieved items to your ListView
            ListView foodsListView = findViewById(R.id.foodsListViewSubmitPage);
            FoodOnTripAdapter adapter = new FoodOnTripAdapter(this, items);
            foodsListView.setAdapter(adapter);
        }

        // deal with back to add food button
        ImageButton backButton = findViewById(R.id.backToAddFoodButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the button click event
                Intent intent = new Intent(SaveNewTripActivity.this, AddFoodToTripActivity.class);
                startActivity(intent);
            }
        });

        // deal with add trip button
        Button addTripButton = findViewById(R.id.saveNewTripButton);
        addTripButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                Calendar calendar = Calendar.getInstance();
                Date defaultDate = calendar.getTime();
                Date startDateDateType = defaultDate;
                Date endDateDateType = defaultDate;

                try {
                    startDateDateType = dateFormat.parse(startDate);
                    endDateDateType = dateFormat.parse(endDate);
                } catch (ParseException e) {
                    startDateDateType = defaultDate;
                    endDateDateType = defaultDate;
                }

                // put the foods in the real food list
                if (foodList != null && !foodList.isEmpty()) {
                    // Iterate through the foodList using a for-each loop
                    for (Food food : foodList) {
                        // Access each Food object and its properties here
                        String nameOfFood = food.getName();
                        String whereBought = food.getCountry();
                        double foodRating = food.getRating();
                        ArrayList<String> imageList = food.getPhotos();
                        Food foodToAdd = new Food(nameOfFood, foodRating, imageList, whereBought, new Position(), new Date(), 0);
                        Integer idx = MainActivity.globalgrub.addFood(foodToAdd);
                        foodIdList.add(idx);
                    }
                }
                // erase the temp list
                if (foodList != null) {
                    foodList.clear();
                }

                // foodIdList = MainActivity.globalgrub.getAllFoods();
                Trip trip = new Trip(startDateDateType, endDateDateType, countryText, foodIdList, 0);
//                System.out.println("foodList[0]: " + foodIdList.get(0));
                MainActivity.globalgrub.addTrip(trip);
                Intent intent = new Intent(SaveNewTripActivity.this, TripActivity.class);
                showCustomPopUp(view, "Your trip was successfully added!");
                intent.putExtra("SHOW_POPUP", true);
                startActivity(intent);
            }
        });
    }

}