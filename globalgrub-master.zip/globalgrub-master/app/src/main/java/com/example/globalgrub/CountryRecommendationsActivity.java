package com.example.globalgrub;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.adapters.RecommendationAdapter;
import com.example.globalgrub.model.Recommendation;

import java.util.List;

public class CountryRecommendationsActivity extends AppCompatActivity{

    private ListView recommendationsListView;
    private List<Recommendation> foodRecommend;
    private RecommendationAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.country_recommend);
        Intent intent = getIntent();
        String selectedCountry = intent.getStringExtra("selected_country");

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        // set same onclick handler for all buttons
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button2.setImageResource(R.drawable.recommend_clicked);
        TextView recommend_text = findViewById(R.id.recommend_text);
        recommend_text.setTextColor(Color.parseColor("#BCA538"));

        foodRecommend = MainActivity.globalgrub.getRecommendationList(selectedCountry);
        recommendationsListView = findViewById(R.id.recommendationsListView);
        ImageButton backButton = findViewById(R.id.country_rec_back);
        TextView title = findViewById(R.id.country_rec_title);
        title.setText(selectedCountry + "'s Dishes");

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // go back to SearchActivity
                Intent intent = new Intent(CountryRecommendationsActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        // get recommended food based on countries
//        List<Recommend> countryRecommendations = globalGrub.getRecommendationList(selectedCountry);
//        List<Recommendation> recommendationList = recommendationManager.getRecommendationList("China");

        adapter = new RecommendationAdapter(this, foodRecommend);

        recommendationsListView.setAdapter(adapter);
    }



}
