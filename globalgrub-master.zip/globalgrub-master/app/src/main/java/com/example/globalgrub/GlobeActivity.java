package com.example.globalgrub;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GlobeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.globe_page);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);

        // 为每个按钮设置相同的点击事件处理器
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button1.setImageResource(R.drawable.globe_clicked);
        TextView home_text = findViewById(R.id.home_text);
        home_text.setTextColor(Color.parseColor("#BCA538"));

        // deal with add trip button
        Button addTripButton = findViewById(R.id.add_trip_button);

        addTripButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the button click event
                Intent intent = new Intent(GlobeActivity.this, AddTripActivity.class);
                startActivity(intent);
            }
        });
    }
}