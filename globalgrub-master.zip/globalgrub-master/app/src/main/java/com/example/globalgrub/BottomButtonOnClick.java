package com.example.globalgrub;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;

public class BottomButtonOnClick implements View.OnClickListener {

    private Context context;

    public BottomButtonOnClick(Context context) {
        this.context = context;
    }

    @Override
    public void onClick(View v) {
        int viewId = v.getId();

        if (v instanceof ImageButton) {
            ImageButton imgBtn = (ImageButton) v;
            if (viewId == R.id.globe_button) {
                navigateTo(GlobeActivity.class);
                ((Activity) context).finish();
                imgBtn.setImageResource(R.drawable.globe_clicked);
            } else if (viewId == R.id.search_button) {
                navigateTo(SearchActivity.class);
                ((Activity) context).finish();
                imgBtn.setImageResource(R.drawable.recommend_clicked);
            } else if (viewId == R.id.dish_button) {
                navigateTo(DishActivity.class);
                ((Activity) context).finish();
                imgBtn.setImageResource(R.drawable.fast_food_clicked);
            } else if (viewId == R.id.trip_button) {
                navigateTo(TripActivity.class);
                ((Activity) context).finish();
                imgBtn.setImageResource(R.drawable.flight_trip_clicked);
            }
        }
    }

    private void navigateTo(Class<?> destinationActivity) {
        Intent intent = new Intent(context, destinationActivity);
        context.startActivity(intent);
    }
}
