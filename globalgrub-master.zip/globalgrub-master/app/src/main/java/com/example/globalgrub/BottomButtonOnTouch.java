package com.example.globalgrub;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;

public class BottomButtonOnTouch implements View.OnTouchListener {

    private Context context;

    public BottomButtonOnTouch(Context context) {
        this.context = context;
    }

    @Override
    public boolean onTouch(View v, MotionEvent e) {
        int viewId = v.getId();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (v instanceof ImageButton) {
                    ImageButton imgBtn = (ImageButton) v;
                    if (viewId == R.id.globe_button) {
                        imgBtn.setImageResource(R.drawable.globe_clicked);
                    } else if (viewId == R.id.search_button) {
                        imgBtn.setImageResource(R.drawable.recommend_clicked);
                    } else if (viewId == R.id.dish_button) {
                        imgBtn.setImageResource(R.drawable.fast_food_clicked);
                    } else if (viewId == R.id.trip_button) {
                        imgBtn.setImageResource(R.drawable.flight_trip_clicked);
                    }
                }
                break;
//            case MotionEvent.ACTION_UP:
//                if (v instanceof ImageButton) {
//                    ImageButton imgBtn = (ImageButton) v;
//                    if (viewId == R.id.globe_button) {
//                        imgBtn.setImageResource(R.drawable.globe_clicked);
//                    } else if (viewId == R.id.search_button) {
//                        imgBtn.setImageResource(R.drawable.recommend_clicked);
//                    } else if (viewId == R.id.dish_button) {
//                        imgBtn.setImageResource(R.drawable.fast_food_clicked);
//                    } else if (viewId == R.id.trip_button) {
//                        imgBtn.setImageResource(R.drawable.flight_trip_clicked);
//                    }
//                }
//                break;
        }
        return false;
    }
}