package com.example.globalgrub.manager;

import com.example.globalgrub.model.Trip;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class TripManager{
    private Hashtable<Integer, Trip> trips;
    private Integer id = 0;
    public TripManager(){
        trips = new Hashtable<Integer, Trip>();
        id = 0;
    }
    public Integer addTrip(Trip trip){
        trip.setId(id);
        trips.put(id, trip);
        id++;
        return id-1;
    }
    public boolean deleteTrip(Integer id){
        if(!trips.containsKey(id)){
            return false;
        }
        trips.remove(id);
        return true;
    }
    public boolean editTrip(Integer id, Trip trip){
        if(!trips.containsKey(id)){
            return false;
        }
        trips.put(id, trip);
        return true;
    }
    public Trip getTrip(Integer id){
        if(!trips.containsKey(id)){
            return null;
        }
        return trips.get(id);
    }
    public Hashtable<Integer, Trip> getTrips(){
        return trips;
    }
    public List<Trip> getTripList(){
        return new ArrayList<>(trips.values());
    }
}