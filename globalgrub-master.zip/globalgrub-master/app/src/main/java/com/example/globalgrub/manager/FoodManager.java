package com.example.globalgrub.manager;

import com.example.globalgrub.model.Food;
import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;

public class FoodManager {
    private Hashtable<Integer, Food> foods;
    private Integer id = 0;

    public FoodManager() {
        foods = new Hashtable<>();
        id = 0;
    }

    public Integer addFood(Food food) {
        food.setId(id);
        foods.put(id, food);
        id++;
        return id-1;
    }

    public void deleteFood(int index) {
        foods.remove(index);
    }

    public void editFood(int index, Food food) {
        foods.put(index, food);
    }

    public Food getFood(int index) {
        return foods.get(index);
    }

    public Hashtable<Integer, Food> getFoods() {
        return foods;
    }

    public List<Food> getFoodList() {
        return new ArrayList<>(foods.values());
    }
    // Additional methods like getFoodsByCountry, getFoodsByRating...
}