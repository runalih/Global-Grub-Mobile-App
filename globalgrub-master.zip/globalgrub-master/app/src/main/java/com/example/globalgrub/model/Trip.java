package com.example.globalgrub.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class Trip implements Serializable {
    private  int id;
    private Date startDate;
    private Date endDate;
    private String country;
    private ArrayList<Integer> foodIDs;
    public Trip(){
        this.startDate = new Date();
        this.endDate = new Date();
        this.country = "Test Country";
        this.foodIDs = new ArrayList<Integer>();
    
    }
    public Trip(Trip t){
        this.startDate = t.startDate;
        this.endDate = t.endDate;
        this.country = t.country;
        this.foodIDs = new ArrayList<>();
        for(int i  = 0; i < t.getFoodIDs().size(); ++i ){
            this.foodIDs.add(t.getFoodIDs().get(i));
        }

    }
    public Trip(Date startDate, Date endDate, String country, ArrayList<Integer> foodIDs, int id){
        this.startDate = startDate;
        this.endDate = endDate;
        this.country = country;
        this.foodIDs = foodIDs;
        this.id = id;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public ArrayList<Integer> getFoodIDs() {
        return foodIDs;
    }

    public void setFoodIDs(ArrayList<Integer> foodIDs) {
        this.foodIDs = foodIDs;
    }
}