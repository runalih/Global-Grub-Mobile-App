package com.example.globalgrub;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private EditText editTextSearch;
    private ListView listViewCountries;
    private List<String> filteredCountries;

//    private GlobalGrub globalGrub = new GlobalGrub();
    private List<String> allCountries;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        allCountries = new ArrayList<>(MainActivity.globalgrub.getCountries().keySet());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_page);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        // set same onclick handler for all buttons
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button2.setImageResource(R.drawable.recommend_clicked);
        TextView recommend_text = findViewById(R.id.recommend_text);
        recommend_text.setTextColor(Color.parseColor("#BCA538"));

        editTextSearch = findViewById(R.id.editTextSearch);
        listViewCountries = findViewById(R.id.listViewCountries);
        RelativeLayout maskLayout = findViewById(R.id.search_mask_layout);
        filteredCountries = new ArrayList<>();

        // set up an adapter
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, filteredCountries);
        listViewCountries.setAdapter(adapter);

        // listen for text changes
        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
//                Toast.makeText(SearchActivity.this, allCountries.get(0), Toast.LENGTH_SHORT).show();
                maskLayout.setVisibility(View.GONE);
                filterCountries(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        listViewCountries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selectedCountry = filteredCountries.get(position);
                editTextSearch.setText(selectedCountry);
                listViewCountries.setVisibility(View.GONE);

            }
        });

        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!allCountries.contains(editTextSearch.getText().toString())) {
                    maskLayout.setVisibility(View.VISIBLE);
                } else {
                    navigateToCountryRecommendations(editTextSearch.getText().toString());
                }
            }
        });
    }

    // filter country list based on current input
    private void filterCountries(String searchText) {
        filteredCountries.clear();

        for (String country : allCountries) {
            if (country.toLowerCase().contains(searchText.toLowerCase())) {
                filteredCountries.add(country);
            }

            // limit top 5 countries
            if (filteredCountries.size() >= 5) {
                break;
            }

//            Toast.makeText(SearchActivity.this, country, Toast.LENGTH_SHORT).show();
        }

        // update the adapter
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) listViewCountries.getAdapter();
        adapter.notifyDataSetChanged();
    }

    private void navigateToCountryRecommendations(String selectedCountry) {
        // navigate to the selected country
        Intent intent = new Intent(SearchActivity.this, CountryRecommendationsActivity.class);
        intent.putExtra("selected_country", selectedCountry);
        startActivity(intent);
    }


}
