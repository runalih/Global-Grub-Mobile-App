package com.example.globalgrub.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.example.globalgrub.CountryRecommendationsActivity;
import com.example.globalgrub.MainActivity;
import com.example.globalgrub.R;
import com.example.globalgrub.model.Recommendation;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class RecommendationAdapter extends ArrayAdapter<Recommendation> {
    private Context context;
    private List<Recommendation> recommendations;

    public RecommendationAdapter(Context context, List<Recommendation> recommendations) {
        super(context, R.layout.list_item_recommendation, recommendations);
        this.context = context;
        this.recommendations = recommendations;
    }
    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_recommendation, parent, false);
        }

        Recommendation currentRecommendation = getItem(position);

        // random checking
        if (!currentRecommendation.getEaten()) {
            View subLayout = convertView.findViewById(R.id.circleImageView);
            View subLayout2 = convertView.findViewById(R.id.tried_text);
            subLayout.setVisibility(View.GONE);
            subLayout2.setVisibility(View.GONE);
        }

        if (currentRecommendation != null) {
            // find relative views
            TextView nameTextView = convertView.findViewById(R.id.list_item_rec_food_title);
            ImageView foodImageView = convertView.findViewById(R.id.list_item_rec_food_img);
//            TextView rating = convertView.findViewById(R.id.list_item_rec_rating);
            // random rating
//            Random random = new Random();
//            int randomNumber = random.nextInt(5 - 3 + 1) + 3;
//            rating.setText("/ " + randomNumber);
            // set food name
            nameTextView.setText(currentRecommendation.getName());

            nameTextView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showPopup(currentRecommendation, v); // Show popup on nameTextView click
                }
            });

            foodImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(currentRecommendation.getEaten()){
                        currentRecommendation.setEaten(false);
                    }else{
                        currentRecommendation.setEaten(true);
                    }


                    Hashtable<String, List<Recommendation>> hrs = MainActivity.globalgrub.getRecommendation();
                    Set<String> keys = hrs.keySet();
                    Iterator<String> itr = keys.iterator();

                    while (itr.hasNext()) {
                        // Getting Key
                        String key = itr.next();

                        for(Recommendation r : MainActivity.globalgrub.getRecommendationList(key)){
                            if(r.getName() == currentRecommendation.getName()){
                                Intent intent = new Intent(context, CountryRecommendationsActivity.class);
                                intent.putExtra("selected_country", key);
                                context.startActivity(intent);
                            }
                        }
                    }


                }
            });

            // 使用Glide加载图片，需要在build.gradle中添加相应的依赖
            // implementation 'com.github.bumptech.glide:glide:4.12.0'
            String imgPathWithExtension = currentRecommendation.getPhotos().get(0);
//            int lastDotIdx = imgPathWithExtension.lastIndexOf('.');
//            String imgPathWithoutExtension = imgPathWithExtension.substring(0, lastDotIdx);
            Glide.with(context)
//                    .load("android.resource://" + context.getPackageName() + "/drawable/" + imgPathWithoutExtension)
                    .load(Uri.parse("file:///android_asset/food/" + imgPathWithExtension))
                    .apply(new RequestOptions()
                            .diskCacheStrategy(DiskCacheStrategy.NONE)
                            .skipMemoryCache(true))
                    .into(foodImageView);
        }

        return convertView;
    }

    private void showPopup(Recommendation recommendation, View anchorView) {
        View popupView = LayoutInflater.from(context).inflate(R.layout.popup_recommendation, null);

        int width = ViewGroup.LayoutParams.WRAP_CONTENT;
        int height = ViewGroup.LayoutParams.WRAP_CONTENT;

        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, true);
        popupWindow.setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView popupNameTextView = popupView.findViewById(R.id.popup_rec_name);
        ImageView popupImageView = popupView.findViewById(R.id.popup_rec_image);

        popupNameTextView.setText(recommendation.getName());

        String imgPathWithExtension = recommendation.getPhotos().get(0);
        Glide.with(context)
                .load(Uri.parse("file:///android_asset/food/" + imgPathWithExtension))
                .apply(new RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.NONE)
                        .skipMemoryCache(true))
                .into(popupImageView);

        TextView popupCountryTextView = popupView.findViewById(R.id.popup_rec_country);
        TextView popupHistoryTextView = popupView.findViewById(R.id.popup_rec_history);
        TextView popupIngredientsTextView = popupView.findViewById(R.id.popup_rec_ingredients);

        popupCountryTextView.setText(String.format(Locale.getDefault(), "Country: %s", recommendation.getCountry()));
        popupHistoryTextView.setText(String.format(Locale.getDefault(), "History: %s", recommendation.getHistory()));
        popupIngredientsTextView.setText(String.format(Locale.getDefault(), "Ingredients: %s", recommendation.getIngredients()));

        ImageButton btnClosePopup = popupView.findViewById(R.id.btnClosePopup);
        btnClosePopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss(); // Dismiss the popup window on close button click
            }
        });

        popupWindow.showAtLocation(anchorView, Gravity.CENTER, 0, 0);
    }
}
