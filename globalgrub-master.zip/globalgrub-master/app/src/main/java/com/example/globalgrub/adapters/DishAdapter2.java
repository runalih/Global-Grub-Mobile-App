package com.example.globalgrub.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.globalgrub.MainActivity;
import com.example.globalgrub.R;
import com.example.globalgrub.model.Food;

import java.util.List;

public class DishAdapter2 extends ArrayAdapter<Food>{
    private final Activity context;
    private final List<Food> foods;

    public DishAdapter2(Activity context, List<Food> foods) {
        super(context, R.layout.list_food, foods);
        // TODO Auto-generated constructor stub

        this.context = context;
        this.foods = foods;
    }

    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.list_food, null,true);

        TextView foodNameText = (TextView) rowView.findViewById(R.id.foodName);
        TextView placeText = (TextView) rowView.findViewById(R.id.place);
        TextView dateText = (TextView) rowView.findViewById(R.id.date);

        Food currentFood = MainActivity.globalgrub.getFood(getItem(position).getId());

        foodNameText.setText(currentFood.getName());
        placeText.setText(currentFood.getCountry());
        if(currentFood.getDate() == null){
            dateText.setText("2020-11-11");
        }else{
            dateText.setText(currentFood.getDate().toString());
        }


        return rowView;

    };
}
