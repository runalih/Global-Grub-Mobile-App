package com.example.globalgrub.manager;

import com.example.globalgrub.model.Country;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

public class CountryManager {
    private Hashtable <String,Country> countries;
    public CountryManager() {
        countries = new Hashtable<>();
    }

    public void addCountry(Country country) {
        countries.put(country.getName(), country);
    }

    public void removeCountry(String country) {
        countries.remove(country);
    }

    public boolean containsCountry(String country) {
        return countries.containsKey(country);
    }

    public Hashtable<String,Country> getCountries() {
        return countries;
    }

    public List<Country> getCountryList() {
        return new ArrayList<>(countries.values());
    }
}