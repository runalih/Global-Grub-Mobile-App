package com.example.globalgrub.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.globalgrub.R;
import com.example.globalgrub.model.Food;

import java.util.List;

public class DishAdapter extends ArrayAdapter<Food>  {
    private final Activity context;
    private final List<Food> foods;

    public DishAdapter(Activity context, List<Food> foods) {
        super(context, R.layout.list_food, foods);
        this.context = context;
        this.foods = foods;

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater=context.getLayoutInflater();
            View rowView=inflater.inflate(R.layout.list_food, null,true);
        }

        Food currentFood = getItem(position);
        if (currentFood != null){
//            TextView nameTextView = convertView.findViewById(R.id.list_item_rec_food_title);
//            ImageView foodImageView = convertView.findViewById(R.id.list_item_rec_food_img);
//            TextView rating = convertView.findViewById(R.id.list_item_rec_rating);
            TextView foodNameText = (TextView) convertView.findViewById(R.id.foodName);
            TextView placeText = (TextView) convertView.findViewById(R.id.place);
            TextView dateText = (TextView) convertView.findViewById(R.id.date);

            foodNameText.setText(currentFood.getName());
            placeText.setText(currentFood.getCountry());
            dateText.setText(currentFood.getDate().toString());

        }
        return convertView;

    };
}
