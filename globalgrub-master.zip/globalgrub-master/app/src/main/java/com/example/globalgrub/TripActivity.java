package com.example.globalgrub;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.adapters.TripAdapter;
import com.example.globalgrub.model.Trip;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TripActivity extends AppCompatActivity {
    private List<String> allCountries;
    private List<String>filteredCountries;
    private ListView listViewCountries;
    private List<Trip> tripList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        allCountries = new ArrayList<>(MainActivity.globalgrub.getCountries().keySet());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trip_page);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        // set same onclick handler for all buttons
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button4.setImageResource(R.drawable.flight_trip_clicked);
        TextView trip_text = findViewById(R.id.trip_text);
        trip_text.setTextColor(Color.parseColor("#BCA538"));

//        System.out.println(MainActivity.globalgrub.getCountryList());

        EditText editTextSearch = findViewById(R.id.editTextSearch);
        listViewCountries = findViewById(R.id.listViewCountries);
        RelativeLayout maskLayout = findViewById(R.id.search_mask_layout);
        filteredCountries = new ArrayList<>();
        final ArrayAdapter<String> adapter_search = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, filteredCountries);
        listViewCountries.setAdapter(adapter_search);

        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
//                Toast.makeText(SearchActivity.this, allCountries.get(0), Toast.LENGTH_SHORT).show();
                maskLayout.setVisibility(View.GONE);
                filterCountries(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        listViewCountries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String selectedCountry = filteredCountries.get(position);
                editTextSearch.setText(selectedCountry);
                listViewCountries.setVisibility(View.GONE);

            }
        });

        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!allCountries.contains(editTextSearch.getText().toString())) {
                    maskLayout.setVisibility(View.VISIBLE);
                } else {
                    navigateToCountryRecommendations(editTextSearch.getText().toString());
                }
            }
        });

        // render the list of the trips
        tripList = MainActivity.globalgrub.getTripList();
        if (tripList != null && !tripList.isEmpty()) {
            List<Trip> items = new ArrayList<>();

            // Convert trip items to a format compatible with your adapter
            for (Trip trip : tripList) {
                String nameOfCountry = trip.getCountry();
                Date tripStartDate = trip.getStartDate(); // Get 'whereBought' from Food object
                Date tripEndDate = trip.getEndDate();
//                String stringDate = String.valueOf(date); // Convert double to string
                ArrayList<Integer> foodIds = trip.getFoodIDs();
                items.add(new Trip(tripStartDate, tripEndDate, nameOfCountry, foodIds, trip.getId()));
            }

            // Set the adapter with the retrieved items to your ListView
            ListView tripsListView = findViewById(R.id.tripListView);
            TripAdapter adapter = new TripAdapter(this, items);
            tripsListView.setAdapter(adapter);
        }
    }

    private void filterCountries(String searchText) {
        filteredCountries.clear();

        for (String country : allCountries) {
            if (country.toLowerCase().contains(searchText.toLowerCase())) {
                filteredCountries.add(country);
            }

            // limit top 5 countries
            if (filteredCountries.size() >= 5) {
                break;
            }

//            Toast.makeText(SearchActivity.this, country, Toast.LENGTH_SHORT).show();
        }

        // update the adapter
        ArrayAdapter<String> adapter = (ArrayAdapter<String>)listViewCountries.getAdapter();
        adapter.notifyDataSetChanged();
    }

    private void showCustomPopUp(View parentView, String message) {
        // Inflate the layout for the pop-up
        LayoutInflater inflater = LayoutInflater.from(TripActivity.this);
        View customView = inflater.inflate(R.layout.custom_popup_layout, null);

        // Set the message
        TextView textView = customView.findViewById(R.id.popup_message);
        textView.setText(message);

        // Create a PopupWindow
        PopupWindow popupWindow = new PopupWindow(
                customView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );

        popupWindow.showAtLocation(parentView, Gravity.CENTER, 0, 0);

        // Close the pop-up after a delay (here, 4000 milliseconds)
        new Handler().postDelayed(popupWindow::dismiss, 20000);
    }

    private void navigateToCountryRecommendations(String selectedCountry) {

        List<Trip> selectedCountryTrips = new ArrayList<>();

        // Filter trips for the selected country
        for (Trip trip : tripList) {
            if (trip.getCountry().equalsIgnoreCase(selectedCountry)) {
                selectedCountryTrips.add(trip);
            }
        }

        // Render the list of selected country trips
        if (!selectedCountryTrips.isEmpty()) {
            List<Trip> items = new ArrayList<>();

            // Convert selected country trip items to a format compatible with your adapter
            for (Trip trip : selectedCountryTrips) {
                String nameOfCountry = trip.getCountry();
                Date tripStartDate = trip.getStartDate();
                Date tripEndDate = trip.getEndDate();
//                String stringDate = String.valueOf(tripStartDate);
                List<Integer> foodIDs = trip.getFoodIDs();
                items.add(new Trip(tripStartDate, tripEndDate, nameOfCountry, (ArrayList<Integer>) foodIDs, trip.getId()));
            }

            // Set the adapter with the retrieved items to your ListView
            ListView tripsListView = findViewById(R.id.tripListView);
            TripAdapter adapter = new TripAdapter(this, items);
            tripsListView.setAdapter(adapter);
        } else {
            // If there are no trips for the selected country, you can handle it accordingly
            // For example, show a message or clear the list view
            ListView tripsListView = findViewById(R.id.tripListView);
            tripsListView.setAdapter(null);
        }
    }
}