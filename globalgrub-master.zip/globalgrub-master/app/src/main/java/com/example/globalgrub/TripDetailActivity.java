package com.example.globalgrub;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.adapters.TripFoodAdapter;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Trip;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TripDetailActivity extends AppCompatActivity {
    private TextView countryTextView;
    private TextView date1TextView;
    private TextView date2TextView;
    private ListView foodListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trip_detail);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        // set same onclick handler for all buttons
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button4.setImageResource(R.drawable.flight_trip_clicked);
        TextView trip_text = findViewById(R.id.trip_text);
        trip_text.setTextColor(Color.parseColor("#BCA538"));

        // get trip obj
        Trip currentTrip = (Trip) getIntent().getSerializableExtra("trip");

        // init ui
        countryTextView = findViewById(R.id.countryTextView);
        date1TextView = findViewById(R.id.date1TextView);
        date2TextView = findViewById(R.id.date2TextView);
        foodListView = findViewById(R.id.foodListView);

        // set the text of textview
        countryTextView.setText(currentTrip.getCountry());
        date1TextView.setText(processDateString(currentTrip.getStartDate().toString()));
        date2TextView.setText(processDateString(currentTrip.getEndDate().toString()));

        List<Integer> foodIDs = currentTrip.getFoodIDs();
        List<Food> foods = new ArrayList<>();
        for (Integer foodID : foodIDs) {
            foods.add(MainActivity.globalgrub.getFood(foodID));
        }

        // set adapter on listview
        TripFoodAdapter foodAdapter = new TripFoodAdapter(this, foods);
        foodListView.setAdapter(foodAdapter);

        ImageButton backButton = findViewById(R.id.trip_detail_back);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // go back to SearchActivity
                Intent intent = new Intent(TripDetailActivity.this, TripActivity.class);
                startActivity(intent);
            }
        });

        ImageButton editButton = findViewById(R.id.trip_detail_edit);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // go back to SearchActivity
                Intent intent = new Intent(TripDetailActivity.this, TripDetailEditActivity.class);
                intent.putExtra("trip", currentTrip);
                startActivity(intent);
            }
        });
    }

    private static String processDateString(String input) {
//        input = input.replace("CST ", "");
        SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy");

        try {
            Date date = inputFormat.parse(input);
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid Date";
        }
    }
}