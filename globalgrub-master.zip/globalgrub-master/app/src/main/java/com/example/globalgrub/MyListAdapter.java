package com.example.globalgrub;

import android.app.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class MyListAdapter extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] foodName;
    private final String[] place;
    private final String[] date;

    public MyListAdapter(Activity context, String[] foodName,String[] place, String[] date) {
        super(context, R.layout.list_food, foodName);
        // TODO Auto-generated constructor stub

        this.context = context;
        this.foodName = foodName;
        this.place = place;
        this.date = date;

    }

    public View getView(int position,View view,ViewGroup parent) {
        LayoutInflater inflater=context.getLayoutInflater();
        View rowView=inflater.inflate(R.layout.list_food, null,true);

        TextView foodNameText = (TextView) rowView.findViewById(R.id.foodName);
        TextView placeText = (TextView) rowView.findViewById(R.id.place);
        TextView dateText = (TextView) rowView.findViewById(R.id.date);

        foodNameText.setText(foodName[position]);
        placeText.setText(place[position]);
        dateText.setText(date[position]);

        return rowView;

    };
}