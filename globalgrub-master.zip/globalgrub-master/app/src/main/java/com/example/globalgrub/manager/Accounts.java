package com.example.globalgrub.manager;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import android.content.Context;

public class Accounts{
    Hashtable<String, String> accounts;
    public Accounts(Context context){
        accounts = new Hashtable<String, String>();
    }
    public boolean addAccount(String username, String password){
        if(accounts.containsKey(username)){
            return false;
        }
        accounts.put(username, password);
        return true;
    }
    public boolean deleteAccount(String username){
        if(!accounts.containsKey(username)){
            return false;
        }
        accounts.remove(username);
        return true;
    }
    public boolean login(String username, String password){
        if(!accounts.containsKey(username)){
            return false;
        }
        if(!accounts.get(username).equals(password)){
            return false;
        }
        return true;
    }
    public boolean changePassword(String username, String password){
        if(!accounts.containsKey(username)){
            return false;
        }
        accounts.put(username, password);
        return true;
    }
    public Hashtable<String, String> getAccounts(){
        return accounts;
    }
    public List<String> getAccountList(){
        return new ArrayList<>(accounts.values());
    }
}