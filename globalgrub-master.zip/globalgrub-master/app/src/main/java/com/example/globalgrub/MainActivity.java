package com.example.globalgrub;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.os.Bundle;
//import android.widget.ImageButton;
//import android.view.MotionEvent;
//import android.view.View;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        ImageButton myImageButton = findViewById(R.id.dish_button);
//
//        myImageButton.setOnHoverListener(new View.OnHoverListener() {
//            @Override
//            public boolean onHover(View v, MotionEvent event) {
//                switch (event.getAction()) {
//                    case MotionEvent.ACTION_HOVER_ENTER:
//                        // Change image to the hovered state
//                        myImageButton.setImageResource(R.drawable.button_hover);
//                        return true;
//                    case MotionEvent.ACTION_HOVER_EXIT:
//                        // Change image back to the normal state
//                        myImageButton.setImageResource(R.drawable.button_normal);
//                        return true;
//                    default:
//                        return false;
//                }
//            }
//        });
//    }
//
//}

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.manager.Accounts;
import com.example.globalgrub.manager.GlobalGrub;

public class MainActivity extends AppCompatActivity {
    
    public static GlobalGrub globalgrub;
    public static Accounts accounts;

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        globalgrub = new GlobalGrub(this.getApplicationContext());
        accounts = new Accounts(this.getApplicationContext());

        // Initialize UI components
        usernameEditText = findViewById(R.id.et_usr_name);
        passwordEditText = findViewById(R.id.et_pwd);
        loginButton = findViewById(R.id.btn_login);

        // Set click listener for the login button
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Add login logic here
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // This is a simple example; you should implement actual login logic based on your requirements
                if (isValidCredentials(username, password)) {
                    // Login successful, navigate to GlobeActivity
                    Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                    navigateToGlobeActivity();
                } else {
                    // Login failed, display an error message or perform other actions
                    usernameEditText.setError("Wrong User of Password");
                    passwordEditText.setError("Wrong User of Password");
//                    Toast.makeText(MainActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
    }

    



    // Add actual username and password validation logic in this method
    private boolean isValidCredentials(String username, String password) {
        // This is a simple example; in a real-world scenario, implement your own validation logic
        return username.equals("admin") && password.equals("123456");
    }

    // Method to navigate to GlobeActivity upon successful login
    private void navigateToGlobeActivity() {
        Intent intent = new Intent(MainActivity.this, GlobeActivity.class);
        startActivity(intent);
        // Optionally, you can finish the current activity to prevent the user from returning to the login screen using the back button
//        finish();
    }
}
