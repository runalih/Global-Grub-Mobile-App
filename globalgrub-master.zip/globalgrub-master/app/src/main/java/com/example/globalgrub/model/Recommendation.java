package com.example.globalgrub.model;

import java.util.ArrayList;
public class Recommendation{
    private Boolean eaten;
    private String name;
    private ArrayList<String> photos;
    private String country;
    private String history;
    private ArrayList<String> ingredients;
    private ArrayList<Position> locationToBuy;
    public Recommendation(){
        this.name = "Test Food";
        this.photos = new ArrayList<String>();
        this.country = "Test Country";
        this.history = "Test History";
        this.ingredients = new ArrayList<String>();
        this.locationToBuy = new ArrayList<Position>();
        this.eaten = false;
    }
    public Recommendation(String name, ArrayList<String> photos, String country, String history, ArrayList<String> ingredients, ArrayList<Position> locationToBuy){
        this.name = name;
        this.photos = photos;
        this.country = country;
        this.history = history;
        this.ingredients = ingredients;
        this.locationToBuy = locationToBuy;
        this.eaten = false;
    }
    public Boolean getEaten(){
        return eaten;
    }
    public void setEaten(Boolean eaten){
        this.eaten = eaten;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<String> getPhotos() {
        return photos;
    }

    public void setPhotos(ArrayList<String> photos) {
        this.photos = photos;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public ArrayList<String> getIngredients() {
        return ingredients;
    }

    public void setIngredients(ArrayList<String> ingredients) {
        this.ingredients = ingredients;
    }

    public ArrayList<Position> getLocationToBuy() {
        return locationToBuy;
    }

    public void setLocationToBuy(ArrayList<Position> locationToBuy) {
        this.locationToBuy = locationToBuy;
    }
}