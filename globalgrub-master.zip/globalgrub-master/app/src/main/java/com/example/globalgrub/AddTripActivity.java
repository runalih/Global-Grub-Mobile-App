package com.example.globalgrub;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AddTripActivity extends AppCompatActivity {
    // TODO: deal with the foods added list
    // TODO: cleanup layout
    private List<String> allCountries;
    private EditText editTextSearch;
    private ListView listViewCountries;
    private List<String> filteredCountries;
    private TextView startDateEditText;
    private TextView endDateEditText;

    private View searchBar;
    private EditText countryFromSearchBar;
    private ArrayList<Integer> foodIdList;

    ArrayAdapter<String> adapter;
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            String foodName = data.getStringExtra("FOOD_NAME");
            String whereBought = data.getStringExtra("WHERE_BOUGHT");
            Double foodRating = data.getDoubleExtra("FOOD_RATING", 0.0);
//            int foodIndex = data.getIntExtra("FOOD_INDEX", -1);
//
//            foodIdList.add(foodIndex);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        allCountries = new ArrayList<>(MainActivity.globalgrub.getCountries().keySet());
        foodIdList = new ArrayList<>();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_trip_page);

        startDateEditText = findViewById(R.id.startDateEditText);
        endDateEditText = findViewById(R.id.endDateEditText);
        searchBar = findViewById(R.id.add_trip_search_bar);
        countryFromSearchBar = searchBar.findViewById(R.id.editTextSearch);

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        // set 4 onclick event handlers for the bottom
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);

        button1.setImageResource(R.drawable.globe_clicked);
        TextView home_text = findViewById(R.id.home_text);
        home_text.setTextColor(Color.parseColor("#BCA538"));

        startDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        AddTripActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // on below line we are setting date to our text view.
                                startDateEditText.setText(getMonth(monthOfYear) + " " + dayOfMonth + ", " + year);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });

        endDateEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        AddTripActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // on below line we are setting date to our text view.
                                endDateEditText.setText(getMonth(monthOfYear) + " " + dayOfMonth + ", " + year);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });


        // deal with add trip button
        ImageButton addFoodsButton = findViewById(R.id.continueToAddFoodsButton);
        addFoodsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // the variables we will need to store in the trip database
                String startDate = startDateEditText.getText().toString();
                String endDate = endDateEditText.getText().toString();
                String countryText = countryFromSearchBar.getText().toString();

                Intent intent = new Intent(AddTripActivity.this, AddFoodToTripActivity.class);
                // send the country, start_date, and end_date to the next class
                intent.putExtra("START_DATE", startDate);
                intent.putExtra("END_DATE", endDate);
                intent.putExtra("COUNTRY_TEXT", countryText);
                startActivity(intent);
            }
        });

        // dealing with search bar
        editTextSearch = findViewById(R.id.editTextSearch);
        listViewCountries = findViewById(R.id.listViewCountries);

        // get all countries
//        allCountries = globalGrub.getCountryList();

        filteredCountries = new ArrayList<>();

        // set up an adapter
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, filteredCountries);
        listViewCountries.setAdapter(adapter);

        // listen for text changes
        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
//                Toast.makeText(SearchActivity.this, allCountries.get(0), Toast.LENGTH_SHORT).show();
                filterCountries(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        listViewCountries.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedCountry = filteredCountries.get(position);
                editTextSearch.setText(selectedCountry);
                listViewCountries.setVisibility(View.GONE);
            }
        });

        Button searchButton = findViewById(R.id.searchButton);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
        });
    }

    private String getMonth(int month) {
        month += 1;
        if (month == 1)
            return "Jan";
        if (month == 2)
            return "Feb";
        if (month == 3)
            return "Mar";
        if (month == 4)
            return "Apr";
        if (month == 5)
            return "May";
        if (month == 6)
            return "Jun";
        if (month == 7)
            return "Jul";
        if (month == 8)
            return "Aug";
        if (month == 9)
            return "Sep";
        if (month == 10)
            return "Oct";
        if (month == 11)
            return "Nov";
        return "Dec";
    }

    // filter countries based on input
    private void filterCountries(String searchText) {
        filteredCountries.clear();

        for (String country : allCountries) {
            if (country.toLowerCase().contains(searchText.toLowerCase())) {
                filteredCountries.add(country);
            }

            // limit top 5 countries to display
            if (filteredCountries.size() >= 5) {
                break;
            }

//            Toast.makeText(SearchActivity.this, country, Toast.LENGTH_SHORT).show();
        }

        // update the adapter
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) listViewCountries.getAdapter();
        adapter.notifyDataSetChanged();
    }

    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker.
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Create a new instance of DatePickerDialog and return it.
            return new DatePickerDialog(requireContext(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the date the user picks.
        }
    }

}