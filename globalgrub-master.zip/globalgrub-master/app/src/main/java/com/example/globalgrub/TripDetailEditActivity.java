package com.example.globalgrub;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import com.example.globalgrub.adapters.TripFoodEditAdapter;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Trip;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
public class TripDetailEditActivity extends AppCompatActivity implements TripFoodEditAdapter.FoodItemDeleteListener {
    private EditText countryEditText;
    private TextView date1EditText;
    private TextView date2EditText;
    private ListView foodListView;
    private ImageButton saveButton;
    private Button deleteButton;
    private ImageButton addFoodButton;
    private Trip currentTrip;
    private Trip originTrip;
    private List<Food> foods;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.trip_detail_edit);


        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        // set same onclick handler for all buttons
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button4.setImageResource(R.drawable.flight_trip_clicked);
        TextView trip_text = findViewById(R.id.trip_text);
        trip_text.setTextColor(Color.parseColor("#BCA538"));
        // Get the Trip object
        originTrip = (Trip) getIntent().getSerializableExtra("trip");
        currentTrip = new Trip(originTrip);
        currentTrip.setId(originTrip.getId());


        // Initialize UI elements
        countryEditText = findViewById(R.id.edit_countryTextView);
        date1EditText = findViewById(R.id.edit_date1TextView);
        date2EditText = findViewById(R.id.edit_date2TextView);
        foodListView = findViewById(R.id.edit_foodListView);
        saveButton = findViewById(R.id.trip_detail_edit_save);
        addFoodButton = findViewById(R.id.trip_detail_edit_add_trip);
        deleteButton = findViewById(R.id.trip_detail_edit_delete);

        // Set the text of EditText
        countryEditText.setText(currentTrip.getCountry());
        date1EditText.setText(processDateString(currentTrip.getStartDate().toString()));
        date2EditText.setText(processDateString(currentTrip.getEndDate().toString()));

        date1EditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        TripDetailEditActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // on below line we are setting date to our text view.
                                date1EditText.setText(getMonth(monthOfYear) + " " + dayOfMonth + ", " + year);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });

        date2EditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(

                        TripDetailEditActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // on below line we are setting date to our text view.
                                date2EditText.setText(getMonth(monthOfYear) + " " + dayOfMonth + ", " + year);
                            }
                        },
                        year, month, day);
                datePickerDialog.show();
            }
        });


        System.out.println("Init Food");
        foods = getFoodsFromTrip(currentTrip);
        for(int i = 0; i < MainActivity.globalgrub.getTempFoodList().size(); ++i){
            foods.add(MainActivity.globalgrub.getTempFoodList().get(i));
        }
        TripFoodEditAdapter adapter = new TripFoodEditAdapter(this, foods, this);
        foodListView.setAdapter(adapter);

        // Implement delete button for each item in the ListView (you need to create this functionality)
        // ...

        ImageButton backButton = findViewById(R.id.edit_trip_detail_back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Go back to TripDetailActivity
                MainActivity.globalgrub.getTempFoodList().clear();
                Intent intent = new Intent(TripDetailEditActivity.this, TripDetailActivity.class);

                intent.putExtra("trip", originTrip);
                startActivity(intent);
                finish();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean valid = true;
                String countryText = countryEditText.getText().toString();
                SimpleDateFormat format = new SimpleDateFormat("MMM dd, yyyy");
                if(countryText.isEmpty()){
                    valid = false;
                    countryEditText.setError("Should not be Empty");
                }else{
                    currentTrip.setCountry(countryText);
                }
                try {
                    Date startDate = format.parse(date1EditText.getText().toString());
                    currentTrip.setStartDate(startDate);
                }catch (Exception e){
                    date1EditText.setError("Wrong Date Format. MMM dd, yyyy");
                    valid = false;
                }
                try {
                    Date endDate = format.parse(date2EditText.getText().toString());
                    currentTrip.setEndDate(endDate);
                }catch (Exception e){
                    date1EditText.setError("Wrong Date Format. MMM dd, yyyy");
                    valid = false;
                }
                if(!valid){
                    return;
                }


                saveFoodListChanges();
                List<Integer> tmpFoodIDs =  currentTrip.getFoodIDs();
                List<Integer> curFoodIDs = MainActivity.globalgrub.getTrip(currentTrip.getId()).getFoodIDs();
                List<Integer> delList = new ArrayList<>();
                for(int id : curFoodIDs){
                    int find = 0;
                    for(int tid : tmpFoodIDs){
                        if(id == tid){
                            find = 1;
                            break;
                        }
                    }
                    if(find == 0){
                        delList.add(id);
                    }
                }
                for(int id : delList){
                    MainActivity.globalgrub.deleteFood(id);
                }

                Intent intent = new Intent(TripDetailEditActivity.this, TripDetailActivity.class);

                List<Integer> currentFoodID = currentTrip.getFoodIDs();
                for(Food f : foods){
                    if(f.getId() == -1){
                        int foodIdx = MainActivity.globalgrub.addFood(f);
                        currentFoodID.add(foodIdx);
                    }
                }
//                List<Food> addedFood = MainActivity.globalgrub.getTempFoodList();
//
//                for (int i = 0; i < addedFood.size(); ++i) {
//                    int foodIdx = MainActivity.globalgrub.addFood(addedFood.get(i));
//                    currentFoodID.add(foodIdx);
//                    System.out.println(foodIdx);
//
//                }
                System.out.println(currentFoodID);
                currentTrip.setFoodIDs((ArrayList<Integer>) currentFoodID);
                MainActivity.globalgrub.getTempFoodList().clear();
                MainActivity.globalgrub.editTrip(currentTrip.getId(), currentTrip);



                intent.putExtra("trip", currentTrip);
                startActivity(intent);
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(TripDetailEditActivity.this);
                builder.setTitle("Confirm Delete");
                builder.setMessage("Are you sure you want to delete the trip?");

                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        Intent intent = new Intent(TripDetailEditActivity.this, TripActivity.class);
                        List<Integer> foodIDs = currentTrip.getFoodIDs();
                        MainActivity.globalgrub.deleteTrip(currentTrip.getId());
                        for(int i : foodIDs){
                            MainActivity.globalgrub.deleteFood(i);
                        }
                        startActivity(intent);
                        finish();
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });


                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        addFoodButton.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TripDetailEditActivity.this, TripDetailEditAddFoodActivity.class);
                intent.putExtra("trip", currentTrip);
                startActivity(intent);
                finish();
            }

        });

    }

    private String getMonth(int month) {
        month += 1;
        if (month == 1)
            return "Jan";
        if (month == 2)
            return "Feb";
        if (month == 3)
            return "Mar";
        if (month == 4)
            return "Apr";
        if (month == 5)
            return "May";
        if (month == 6)
            return "Jun";
        if (month == 7)
            return "Jul";
        if (month == 8)
            return "Aug";
        if (month == 9)
            return "Sep";
        if (month == 10)
            return "Oct";
        if (month == 11)
            return "Nov";
        return "Dec";
    }


    @Override
    public void onFoodItemDelete(int position) {
        foods.remove(position);
        ((TripFoodEditAdapter)foodListView.getAdapter()).notifyDataSetChanged();
    }

    private List<Food> getFoodsFromTrip(Trip trip) {
        List<Food> foods = new ArrayList<>();
        if (trip != null && trip.getFoodIDs() != null) {
            for (Integer foodID : trip.getFoodIDs()) {
                Food food = getFoodById(foodID);
                if (food != null) {
                    foods.add(food);
                }
            }
        }
        return foods;
    }

    private Food getFoodById(int foodId) {
        return MainActivity.globalgrub.getFood(foodId);
    }

    private static String processDateString(String input) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("E MMM dd HH:mm:ss zzz yyyy");
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd, yyyy");

        try {
            Date date = inputFormat.parse(input);
            return outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return "Invalid Date";
        }
    }

    private void saveFoodListChanges() {
        if (currentTrip != null) {
            ArrayList<Integer> newFoodIDs = new ArrayList<>();
            System.out.println("---==---");
            for (Food food : foods) {
                System.out.println(food.getId());
                if(food.getId() >= 0) newFoodIDs.add(food.getId());
//                newFoodIDs.add(food.getId());
            }
            currentTrip.setFoodIDs(newFoodIDs);
        }
    }

    public static class DatePickerFragment extends DialogFragment
            implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current date as the default date in the picker.
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Create a new instance of DatePickerDialog and return it.
            return new DatePickerDialog(requireContext(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the date the user picks.
        }
    }
}