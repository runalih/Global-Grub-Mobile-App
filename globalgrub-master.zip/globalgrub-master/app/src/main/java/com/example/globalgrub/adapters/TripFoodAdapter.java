package com.example.globalgrub.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.globalgrub.DishActivity;
import com.example.globalgrub.R;
import com.example.globalgrub.model.Food;

import java.util.List;

public class TripFoodAdapter extends ArrayAdapter<Food> {
    private final Context context;
    private final List<Food> foods;

    public TripFoodAdapter(Context context, List<Food> foods) {
        super(context, R.layout.list_item_trip_food, foods);
        this.context = context;
        this.foods = foods;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_trip_food, parent, false);
        }

        Food currentFood = getItem(position);

        if (currentFood != null) {
            TextView foodNameView = convertView.findViewById(R.id.trip_food_name);
            TextView foodLocationView = convertView.findViewById(R.id.trip_food_location);
            TextView foodRate = convertView.findViewById(R.id.trip_food_rate);
            ImageView foodImg = convertView.findViewById(R.id.trip_food_img);

            foodNameView.setText(currentFood.getName());
            foodLocationView.setText(currentFood.getCountry());
            foodRate.setText(String.valueOf(currentFood.getRating()));
            if(currentFood.getPhotos().size() != 0){
                foodImg.setImageURI(Uri.parse(currentFood.getPhotos().get(0)));
            }else{
                foodImg.setImageResource(R.drawable.food_icon);
            }
            foodNameView.setOnClickListener(
                    new View.OnClickListener(){
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(context, DishActivity.class);
                            intent.putExtra("foodID", currentFood.getId());
                            context.startActivity(intent);
                        }
                    }
            );

        }

        return convertView;
    }

}

