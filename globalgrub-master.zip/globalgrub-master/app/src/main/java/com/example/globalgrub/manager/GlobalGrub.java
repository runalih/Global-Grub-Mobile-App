package com.example.globalgrub.manager;

import android.content.Context;

import com.example.globalgrub.model.Country;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Recommendation;
import com.example.globalgrub.model.Trip;
import com.example.globalgrub.util.CSVLoader;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;

public class GlobalGrub {
    private CountryManager countryManager;
    private FoodManager foodManager;
    private RecommendationManager recommendationManager;
    private TripManager tripManager;
    private ArrayList<Food> tempFoodList;
    public GlobalGrub(Context context) {
        countryManager = new CountryManager();
        foodManager = new FoodManager();
        recommendationManager = new RecommendationManager();
        tripManager = new TripManager();
        tempFoodList = new ArrayList<Food>();
        CSVLoader csvLoader = new CSVLoader();
        csvLoader.loadCSVToCountryManager(context,"country.csv", countryManager);
        csvLoader.loadCSVToRecommendationManager(context,"recommendation.csv", recommendationManager);
        CSVLoader.loadCSVToFoodManager(context,"food.csv", foodManager);
        // CSVLoader.loadCSVToTripManager("trip.csv", tripManager);
        List<Food> fs = foodManager.getFoodList();
        ArrayList<Integer> fids = new ArrayList<>();
        for(Food f : fs){
            fids.add(f.getId());
        }
        tripManager.addTrip(new Trip(new Date(), new Date(),"United States",fids, 0));
        System.out.println(fids);
    }


    // Delegating methods for FoodManager

    // Food properties: {
    //     name: String,
    //     rating: Integer,
    //     photos: List<String>,
    //     country: String,
    //     position: Position,
    //     date: Date
    // }
    // Position properties: {
    //     lat: Double,
    //     lon: Double
    // }

    // Add Food only if the country exists
    public Integer addFood(Food food) {
        return foodManager.addFood(food);
    }

    // Delete Food with the given index
    public void deleteFood(int index) {
        for(Trip t : this.getTripList()){
            for(int i = 0; i < t.getFoodIDs().size(); i++){
                if(t.getFoodIDs().get(i) == index){
                    t.getFoodIDs().remove(i);
                    break;
                }
            }
        }

        foodManager.deleteFood(index);
    }

    // Edit Food with the given index
    public void editFood(int index, Food food) {
        foodManager.editFood(index, food);
    }

    // Get Food with the given index
    public Food getFood(int index) {
        return foodManager.getFood(index);
    }

    // Get all Foods with index as key
    public Hashtable<Integer, Food> getAllFoods() {
        return foodManager.getFoods();
    }

    // Get all Foods as a list
    public List<Food> getFoodList() {
        return foodManager.getFoodList();
    }

    // Delegating methods for RecommendationManager
    // Recommend properties: {
    //     name: String,
    //     photos: List<String>,
    //     country: String,
    //     history: String,
    //     ingredients: List<String>,
    //     locationToBuy: List<Position>
    // }

    // add Recommendation only if the country exists
    // only called for add data for test. 
    public boolean addRecommendation(String country, Recommendation foodIntro) {
        if (!countryManager.containsCountry(country)) {
            return false;
        }
        return recommendationManager.addRecommendation(country, foodIntro);
    }

    // delete Recommendation with the given index
    // only call for delete data for test.
    public boolean deleteRecommendation(String country, Recommendation foodIntro) {
        return recommendationManager.deleteRecommendation(country, foodIntro);
    }

    // Get all Recommendations with country as key
    public Hashtable<String, List<Recommendation>> getRecommendation() {
        return recommendationManager.getRecommendation();
    }

    // Get all Recommendations as a list
    public List<Recommendation> getRecommendationList(String country) {
        return recommendationManager.getRecommendationList(country);
    }

    // Delegating methods for CountryManager
    // Country properties: {
    //     name: String,
    //     position: Position
    // }
    // Add a country
    // only called for add data for test.
    public void addCountry(Country country) {
        countryManager.addCountry(country);
    }
    // Delete a country
    // only called for delete data for test.
    public void removeCountry(String country) {
        countryManager.removeCountry(country);
    }
    // Check if a country exists
    public boolean containsCountry(String country) {
        return countryManager.containsCountry(country);
    }
    // Get all countries
    public Hashtable<String,Country> getCountries() {
        return countryManager.getCountries();
    }
    // Get all countries as a list
    public List<Country> getCountryList() {
        return countryManager.getCountryList();
    }

    // Delegating methods for TripManager
    // Trip properties: {
    //     date: Date,
    //     country: String,
    //     foodIDs: List<Integer>
    // }
    // Add a trip with the given trip, only if all foodIDs exist
    public Integer addTrip(Trip trip){
        for (Integer foodID : trip.getFoodIDs()) {
            if (foodManager.getFood(foodID) == null) {
                return -1;
            }
        }
        return tripManager.addTrip(trip);
    }
    // Delete a trip with the given id
    public boolean deleteTrip(Integer id){
        return tripManager.deleteTrip(id);
    }
    // Edit a trip with the given id, only if all foodIDs exist
    public boolean editTrip(Integer id, Trip trip){
        for (Integer foodID : trip.getFoodIDs()) {
            if (foodManager.getFood(foodID) == null) {
                return false;
            }
        }
        return tripManager.editTrip(id, trip);
    }
    // Get a trip with the given id
    public Trip getTrip(Integer id){
        return tripManager.getTrip(id);
    }
    // Get all trips with id as key
    public Hashtable<Integer, Trip> getTrips(){
        return tripManager.getTrips();
    }
    // Get all trips as a list
    public List<Trip> getTripList(){
        return tripManager.getTripList();
    }
    public ArrayList<Food> getTempFoodList(){
        return tempFoodList;
    }
    public void setTempFoodList(ArrayList<Food> FL){
        tempFoodList = FL;
    }
}