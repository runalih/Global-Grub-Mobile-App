package com.example.globalgrub;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.globalgrub.adapters.FoodOnTripAdapter;
import com.example.globalgrub.manager.FoodManager;
import com.example.globalgrub.model.Food;
import com.example.globalgrub.model.Position;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AddFoodToTripActivity extends AppCompatActivity {
    private FoodManager foodManager;
    private Uri imageUri;
    private ArrayList<String> imageList;
    private ActivityResultLauncher<Intent> pickImageLauncher;
    private FoodOnTripAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_food_to_trip_page);
        imageList = new ArrayList<>();
        // sets up adapter
        populateFoodList();

        ImageButton button1 = findViewById(R.id.globe_button);
        ImageButton button2 = findViewById(R.id.search_button);
        ImageButton button3 = findViewById(R.id.dish_button);
        ImageButton button4 = findViewById(R.id.trip_button);

        BottomButtonOnClick buttonClickHandler = new BottomButtonOnClick(this);
        BottomButtonOnTouch buttonClickHandler2 = new BottomButtonOnTouch(this);

        button1.setOnTouchListener(buttonClickHandler2);
        button2.setOnTouchListener(buttonClickHandler2);
        button3.setOnTouchListener(buttonClickHandler2);
        button4.setOnTouchListener(buttonClickHandler2);
        button1.setOnClickListener(buttonClickHandler);
        button2.setOnClickListener(buttonClickHandler);
        button3.setOnClickListener(buttonClickHandler);
        button4.setOnClickListener(buttonClickHandler);

        button1.setImageResource(R.drawable.globe_clicked);
        TextView home_text = findViewById(R.id.home_text);
        home_text.setTextColor(Color.parseColor("#BCA538"));

        Intent intent = getIntent();
        String startDate = intent.getStringExtra("START_DATE");
        String endDate = intent.getStringExtra("END_DATE");
        String countryText = intent.getStringExtra("COUNTRY_TEXT");

        final EditText nameOfFoodEditText = findViewById(R.id.nameOfFood);
        final EditText whereBoughtEditText = findViewById(R.id.whereBought);
//        final EditText foodRatingEditText = findViewById(R.id.foodRating);
        final RatingBar foodRatingBar = findViewById(R.id.foodRating);
        Drawable drawable = foodRatingBar.getProgressDrawable();
        drawable.setColorFilter(Color.parseColor("#FFDF00"), PorterDuff.Mode.SRC_ATOP);

        // deal with upload image button
        Button uploadButton = findViewById(R.id.uploadFoodPhotoButton);
        uploadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFilePicker();
            }
        });
        ImageView foodImageView = findViewById(R.id.foodImage);
        pickImageLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        imageUri = result.getData().getData();
                        foodImageView.setImageURI(imageUri);
                        imageList.add(imageUri.toString());
                    }
                });

        // deal with add food to list button
        Button addFoodToList = findViewById(R.id.addFoodsToListButton);

        addFoodToList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the button click event
                String nameOfFood = nameOfFoodEditText.getText().toString();
                String whereBought = whereBoughtEditText.getText().toString();
//                String foodRatingStr = foodRatingEditText.getText().toString();
                int valid = 1;
                // If nameOfFood is empty, set error
                if(nameOfFood.isEmpty()){
                    nameOfFoodEditText.setError("Must Have Value");
                    valid = 0;
                }
                // If whereBought is empty, set error
                if(whereBought.isEmpty()){
                    whereBoughtEditText.setError("Must Have Value");
                    valid = 0;
                }
                // If foodRatingStr is empty, set error
//                if(foodRatingStr.isEmpty()){
//                    foodRatingEditText.setError("Must Have Value");
//                    valid = 0;
//                }
                Double foodRating;
                try {
                    // Attempt to parse the String to a double
                    foodRating = (double) foodRatingBar.getRating();
                    // If rating is out of range, show error
//                    if(foodRating > 5 || foodRating < 0){
//                        foodRatingEditText.setError("Rating should between 0 - 5");
//                        valid = 0;
//                    }
                } catch (NumberFormatException e) {
                    // Handle the case where the input is not a valid double
                    // For instance, show a message to the user or set a default value
                    foodRating = 0.0; // Assigning a default value
                }

                // If there exist any input error, stop the process.
                if(valid == 0)return;

                if (imageList.isEmpty()) {
                    imageList.add("temp");
                }

                // Display the retrieved values in a short Toast message
                Toast.makeText(AddFoodToTripActivity.this, "Food was successfully added!", Toast.LENGTH_SHORT).show();

                // add food to the temp list
                Food food = new Food(nameOfFood, foodRating, imageList, whereBought, new Position(), new Date(), -1);
                ArrayList<Food> tempList = MainActivity.globalgrub.getTempFoodList();
                tempList.add(food);
                MainActivity.globalgrub.setTempFoodList(tempList);

                populateFoodList();

                // remove all text and images in the edit text and image fields
                nameOfFoodEditText.setText("");
                whereBoughtEditText.setText("");
//                foodRatingEditText.setText("");
                foodRatingBar.setRating(0.0f);
                ImageView foodImageView = findViewById(R.id.foodImage);
                foodImageView.setImageResource(R.drawable.food_icon);
                imageList = new ArrayList<>();
            }
        });

        // deal with submit foods and review button
        ImageButton submitFoodsButton = findViewById(R.id.submitFoodsAndReviewButton);

        submitFoodsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the button click event
                Intent intent = new Intent(AddFoodToTripActivity.this, SaveNewTripActivity.class);
                intent.putExtra("START_DATE", startDate);
                intent.putExtra("END_DATE", endDate);
                intent.putExtra("COUNTRY_TEXT", countryText);
                startActivity(intent);
            }
        });
    }



    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*"); // Allow only images
        pickImageLauncher.launch(intent);
    }

    private void populateFoodList() {
        List<Food> foodList = MainActivity.globalgrub.getTempFoodList();
        if (foodList != null && !foodList.isEmpty()) {
            List<String[]> items = new ArrayList<>();

            // Convert Food items to a format compatible with your adapter
            for (Food food : foodList) {
                String nameOfFood = food.getName();
                String whereBought = food.getCountry(); // Get 'whereBought' from Food object
                String foodRating = String.valueOf(food.getRating()); // Convert double to string
                String foodPhoto = String.valueOf(food.getPhotos().get(0));
                items.add(new String[]{nameOfFood, whereBought, foodRating, foodPhoto});
            }

            // Set the adapter with the retrieved items to your ListView
            ListView foodsListView = findViewById(R.id.foodsListViewOnAddFoodPage);
            adapter = new FoodOnTripAdapter(this, items);
            foodsListView.setAdapter(adapter);
        }
    }
}