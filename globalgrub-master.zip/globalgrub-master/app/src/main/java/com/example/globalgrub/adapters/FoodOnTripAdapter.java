package com.example.globalgrub.adapters;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.globalgrub.R;

import java.util.List;

public class FoodOnTripAdapter extends ArrayAdapter<String[]> {
    private final Context context;
    private final List<String[]> values;

    public FoodOnTripAdapter(Context context, List<String[]> values) {
        super(context, R.layout.list_item_foods_on_trip, values);
        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.list_item_foods_on_trip, parent, false);

        TextView text1 = rowView.findViewById(R.id.text1);
        TextView text2 = rowView.findViewById(R.id.text2);
        TextView text3 = rowView.findViewById(R.id.text3);
        ImageView im1 = rowView.findViewById(R.id.imageView1);

        String[] currentItem = values.get(position);

        text1.setText(currentItem[0]);
        text2.setText(currentItem[1]);
        text3.setText(currentItem[2]);
        im1.setImageURI(Uri.parse(currentItem[3]));

        return rowView;
    }
}

