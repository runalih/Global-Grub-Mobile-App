package com.example.globalgrub.model;

public class Position{
    private Double lat;
    private Double lon;
    public Position(){
        this.lat = 94.87;
        this.lon = 77.77;
    }
    public Position(Double lat, Double lon){
        this.lat = lat;
        this.lon = lon;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }
}