package com.example.globalgrub.model;

import java.util.ArrayList;
import java.util.Date;

public class Food{
    private int id;
    private String name;
    private Double rating;
    private ArrayList<String> photos;
    private String country;
    private Position position;
    private Date date;
    public Food(){
        this.name = "Test Food";
        this.rating = 5.0;
        this.photos = new ArrayList<String>();
        this.country = "Test Country";
        this.position = new Position();
        this.date = new Date();
        this.id = 0;
    }
    public Food(String name, Double rating, ArrayList<String> photos, String country, Position position, Date date, int id){
        this.name = name;
        this.rating = rating;
        this.photos = photos;
        this.country = country;
        this.position = position;
        this.date = date;
        this.id = id;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public ArrayList<String> getPhotos() {
        return photos;
    }

    public void setPhotos(ArrayList<String> photos) {
        this.photos = photos;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}