package com.example.globalgrub;

import static org.junit.Assert.assertEquals;

import android.content.Context;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import com.example.globalgrub.manager.GlobalGrub;
import com.example.globalgrub.model.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.ArrayList;
import java.util.Date;
import java.util.Arrays;
import java.util.Hashtable;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private GlobalGrub globalGrub;
    @Before
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.example.globalgrub", appContext.getPackageName());
        globalGrub = new GlobalGrub(appContext);
    }
    @Test
    public void AddFood(){
        Food food = new Food();
        food.setName("HAHA Food");
        food.setRating(4.9);
        food.setCountry("China");
        Integer id = globalGrub.addFood(food);
        System.out.println("Test Return:" + id);
        Food testFood = globalGrub.getFood(id);
        System.out.println(testFood.getName());
        assertEquals(food.getName(), testFood.getName());
        System.out.println(testFood.getRating());
        assertEquals(food.getRating(), testFood.getRating());
        System.out.println(testFood.getCountry());
        assertEquals(food.getCountry(), testFood.getCountry());
    }
    @Test
    public void DeleteFood(){
        Food food = new Food();
        food.setName("HAHA Food");
        food.setRating(4.9);
        food.setCountry("China");
        Integer id = globalGrub.addFood(food);
        System.out.println("Test Return:" + id);
        Food testFood = globalGrub.getFood(id);
        globalGrub.deleteFood(id);
        testFood = globalGrub.getFood(id);
        assertEquals(null, testFood);
    }
    @Test
    public void EditFood(){
        Food food = new Food();
        food.setName("HAHA Food");
        food.setRating(4.9);
        food.setCountry("China");
        Integer id = globalGrub.addFood(food);
        System.out.println("Test Return:" + id);
        Food testFood = globalGrub.getFood(id);
        testFood.setName("HAHAHAHA Food");
        testFood.setRating(3.0);
        testFood.setCountry("Japan");
        globalGrub.editFood(id, testFood);
        testFood = globalGrub.getFood(id);
        assertEquals("HAHAHAHA Food", testFood.getName());
        assertEquals(3.0, testFood.getRating(), 0.01);
        assertEquals("Japan", testFood.getCountry());
    }
    @Test
    public void GetFood(){
        System.out.println("GetFood");
        Hashtable<Integer,Food> f =  globalGrub.getAllFoods();
        for(Integer i : f.keySet()){
            System.out.println(f.get(i).getName() + " ");
            System.out.print(f.get(i).getRating() + " ");
            System.out.print(f.get(i).getCountry());
        }
    }
    @Test
    public void AddTrip(){
        Trip trip = new Trip();
        trip.setCountry("Japan");
        trip.setStartDate(new Date());
        trip.setFoodIDs(new ArrayList<Integer>());
        Integer id = globalGrub.addTrip(trip);
        System.out.println("Test Return:" + id);
        Trip testTrip = globalGrub.getTrip(id);
        System.out.println(testTrip.getCountry());
        assertEquals(trip.getCountry(), testTrip.getCountry());
        System.out.println(testTrip.getStartDate());
        assertEquals(trip.getStartDate(), testTrip.getStartDate());
    }
    @Test
    public void DeleteTrip(){
        Trip trip = new Trip();
        trip.setCountry("Japan");
        trip.setStartDate(new Date());
        trip.setFoodIDs(new ArrayList<Integer>());
        Integer id = globalGrub.addTrip(trip);
        System.out.println("Test Return:" + id);
        Trip testTrip = globalGrub.getTrip(id);
        globalGrub.deleteTrip(id);
        testTrip = globalGrub.getTrip(id);
        assertEquals(null, testTrip);
    }
    @Test
    public void EditTrip(){
        Trip trip = new Trip();
        trip.setCountry("Japan");
        trip.setStartDate(new Date());
        trip.setFoodIDs(new ArrayList<Integer>());
        Integer id = globalGrub.addTrip(trip);
        System.out.println("Test Return:" + id);
        Trip testTrip = globalGrub.getTrip(id);
        testTrip.setCountry("China");
        testTrip.setStartDate(new Date());
        Food food = new Food();
        food.setName("Trip Food");
        food.setRating(4.9);
        food.setCountry("China");
        Integer foodID = globalGrub.addFood(food);
        ArrayList<Integer> foodIDs = new ArrayList<Integer>(Arrays.asList(foodID));
        testTrip.setFoodIDs(foodIDs);
        globalGrub.editTrip(id, testTrip);
        testTrip = globalGrub.getTrip(id);
        assertEquals("China", testTrip.getCountry());
        assertEquals(trip.getStartDate(), testTrip.getStartDate());
        assertEquals(1, testTrip.getFoodIDs().size());
    }

}